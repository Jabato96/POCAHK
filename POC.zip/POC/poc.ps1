echo "Has sido comprometido" 
echo "(Prueba del equipo de TH)"
powershell -noexit -command "echo 'Ahora toca el script powershell' ; ping 8.8.8.8"
timeout 10
